import eDraw as edw
import eDraw.drawing as draw

edw.save(draw.cross(size=100).rotate(45), "/Users/erje/Programs/eDraw/data/16", format="ely, svg")
