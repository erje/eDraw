import eDraw as edw
import eDraw.drawing as draw

edw.save(draw.cross(cx=10,cy=10,size=50), "/Users/erje/Programs/eDraw/data/4", format="ely, svg")
