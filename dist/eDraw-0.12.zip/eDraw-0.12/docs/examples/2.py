import eDraw as edw

edw.save(edw.rect(x=25,y=50,width=10,height=20), "/Users/erje/Programs/eDraw/data/2", format="ely, svg")
